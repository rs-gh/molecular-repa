# MC-GearNet-Edge Per-Residue Encoder Characterization

**Date**: 2026-05-04 (re-run with RankMe metric).
**Encoder**: MC-GearNet-Edge (`MCGearNetEdgePerResidueEncoder`, 6 layers, 3072-dim concat output)
**Checkpoint**: `mc_gearnet_edge.pth` (Zenodo 7593637)
**Data**: 200 PDB train proteins (42,034 residues)
**SLURM**: 28852949 (full sweep). Latest results: [results/20260504_182918/results.json](results/20260504_182918/results.json), [layerwise.csv](results/20260504_182918/layerwise.csv).
**Cross-encoder context**: [../FINDINGS.md](../FINDINGS.md) — for the three-question framing (Q1 information, Q2 saturation, Q3 conditioning) used throughout.

## Summary

**MC-GearNet-Edge is unusable as a REPA target in its current form.** This is a **Q3 conditioning catastrophe** that propagates downstream: the `concat_hidden=True` output concatenates 6 BatchNorm + residual layers whose mean L2 norms grow ~17,700× from layer 0 (82) to layer 5 (1.45 × 10⁶). Layer 5 dominates the concatenated 3072-d output; the whole representation collapses onto a near-1-D subspace (RankMe **12.0 / 3072**, PR **1.04**, **95% of variance in 1 dimension**). The Q2 mean-direction baseline reaches **0.855** test cos-sim, and no projector input (random, AA one-hot, +position) beats it by more than 0.003 — the saturation gap is **+0.002**, an order of magnitude smaller than CA-GearNet's +0.009 and 25× smaller than ESM2's +0.053.

The Q1 evidence supports the same diagnosis: the residue-shuffle test (Q1.1, coords fixed, labels permuted) yields cos = 0.983 — residue identity barely modulates the embedding despite being fed in as node features. Q1.2 geometry is preserved in the sense that 0.5 Å noise drops cos only to 0.81, but the gradient signal sits in the near-1-D exploding subspace and carries almost no information to align against.

## Q1. What information does the encoder encode?

### 1.1 Residue identity

| Metric | Value |
|--------|-------|
| Linear probe accuracy | 14.6% |
| Mean cos between AA centroids | **0.9999** |
| Within-type cos | 0.770 ± 0.365 |
| Between-type cos | 0.729 ± 0.394 |
| Δ (within − between) | **+0.041** |
| Residue-shuffle cos (coords fixed, labels permuted) | **0.983 ± 0.005** |

Per-AA centroids have pairwise cos 0.9999 — they all point in the same direction. The within/between Δ of +0.04 swims inside the ±0.4 standard deviations: it is not a meaningful discrimination signal. Probe accuracy 14.6% is comparable to CA-GearNet's 13.7% — but CA-GearNet doesn't see residue types at all.

**Residue-shuffle cos = 0.983 is the most damning Q1 finding.** MC-GearNet-Edge takes residue identity as its node features (one-hot → 21 dims), and yet permuting the labels within a protein barely moves the embedding. Whatever information the network transmits is neither from *which* residues nor from *where* they are.

### 1.2 3D geometric sensitivity

| Perturbation | Cosine similarity |
|--------------|------------------:|
| 0.1 Å Gaussian | 0.883 ± 0.032 |
| 0.5 Å Gaussian | 0.809 ± 0.063 |
| 1.0 Å Gaussian | 0.783 ± 0.073 |
| 2.0 Å Gaussian | 0.740 ± 0.081 |
| 5.0 Å Gaussian | **0.696 ± 0.110** |
| Random rotation | 0.99974 ± 0.0011 |

CA-GearNet drops to 0.37 at 0.5 Å. MC-GearNet stays above 0.70 even at 5 Å. The embedding is dominated by a direction that depends only weakly on coordinates — consistent with an exploding-BN attractor that all inputs converge toward. **Rotation invariant** (0.99974) — geometry is used only via invariant features, as designed; the bug is in the conditioning, not the symmetry.

### 1.3 Structural context (helix / sheet / loop)

| AA  | within-SS cos | between-SS cos | Δ      |
|-----|--------------:|---------------:|-------:|
| ALA | 0.837         | 0.846          | −0.009 |
| GLY | 0.698         | 0.723          | −0.025 |
| LEU | 0.773         | 0.762          | +0.011 |
| VAL | 0.746         | 0.737          | +0.009 |

Two of four AAs show *negative* delta (between > within), again consistent with noise. CA-GearNet had clear positive deltas for most AAs. MC-GearNet has no meaningful within- vs between-context structure.

### 1.4 Protein-level identity (within-protein vs between-protein)

| Metric                | Value          |
|-----------------------|----------------|
| Within-protein cos    | 0.757 ± 0.376  |
| Between-protein cos   | 0.714 ± 0.402  |
| **Δ**                 | **0.043**      |

Δ 0.043 — residues in the same protein are barely more similar than residues in different proteins, with overlapping ±0.4 std bands. By contrast CA-GearNet has Δ 0.222, ESM2 (sequence-only) has Δ 0.098. Pretraining is contributing essentially nothing to protein-level identity here.

## Q2. How much is reachable from cheap inputs?

3-layer MLP, 80/20 train/test, 300 epochs.

| Input condition          | Train cos | Test cos |
|--------------------------|----------:|---------:|
| Mean direction (no MLP)  |        —  | **0.855** |
| Random 128-d             |    0.864  |    0.857  |
| AA one-hot (21-d)        |    0.862  | **0.858** |

**Saturation gap = best − mean-dir = +0.002.** The projector barely beats the zero-parameter mean-direction baseline. Different inputs (random noise, AA one-hot) land within 0.001 of each other and only ~0.003 above the constant baseline. A 3-layer MLP with hundreds of thousands of parameters and 300 epochs essentially recovers the constant prediction. The target is a ray in 3072-d; any prediction that points down that ray wins, regardless of input.

This is the textbook Q3 → Q2 propagation: rank collapse + norm explosion → variance concentrated on one direction → projector matches by pointing along that ray → REPA has no operating budget.

## Q3. Is the encoder a tractable optimisation target?

**No** — and the rest of this section walks through why each conditioning probe rejects it.

### 3.1 Sparsity & value distribution

| Metric | Value |
|--------|-------|
| Exact zeros | 0.00% |
| Negative values | 85.1% |
| Mean | 601.7 |
| Std | 52 290 |
| Min / Max | −41 487 / **52 008 680** |

Values are enormous — max 5.2 × 10⁷. Fully dense, but "dense" is meaningless when one axis dwarfs the rest.

### 3.2 Effective dimensionality & singular values

| Metric | Value |
|--------|-------|
| Output dim | 3072 |
| **RankMe** | **12.0** |
| Participation ratio | **1.04** |
| Dims for 90% / 95% / 99% variance | **1 / 1 / 2** |
| Top singular value (centered) | 4.3 × 10⁸ |
| S[0] / S[−1] (centered) | **4.3 × 10²⁰** |

**Catastrophic rank collapse.** RankMe 12.0 / 3072 (~0.4% of full rank), PR 1.04 (essentially 1 effective component), and 95% of variance in 1 dimension. The representation occupies a near-1-D subspace; the long tail of small singular values that pushes RankMe above 1 doesn't carry any meaningful variance. S[0]/S[−1] = 10²⁰ is numerical-precision territory — layer 5 (see layer-wise table) accounts for nearly all variance because its norm is ~60× the sum of layers 0–4.

### 3.3 Norms & dead dimensions

| Metric | Value |
|--------|-------|
| Mean L2 norm | **1 476 209** |
| Std L2 norm | 2 494 352 |
| Min / Max | 35.3 / 5.2 × 10⁷ |
| Dead dimensions | **507 / 3072** |
| Dim std range | [0.0, 2.48 × 10⁶] |

Mean norm 1.48 million — ~18 500× CA-GearNet. **507 dead dimensions** — close to one full 512-dim layer slab (any of the early layers; see layer-wise table), confirming one of the 6 concatenated slabs contributes nothing. Norm ratio max/min ≈ 1.5 × 10⁶ per residue — no consistent magnitude scale.

### Root-cause analysis

The three Q3 probes co-fail in a single coherent failure mode: `concat_hidden=True` over 6 BatchNorm + residual layers without a final LayerNorm — norms grow geometrically. Layer 5 has mean L2 ≈ 1.5 million; all earlier layers together contribute < 2% of the output magnitude. The concatenation is effectively layer 5 padded with noise.

## Layer-wise representation

The final output is the **concatenation** of all 6 hidden layers (`concat_hidden=True`), each 512-dim → 3072-d. From [layerwise.csv](results/20260504_182918/layerwise.csv):

| Layer | Dim | RankMe | Mean norm |
|------:|----:|-------:|----------:|
|     0 | 512 |   51.7 |     **82.0** |
|     1 | 512 | **79.6** |       36.0 |
|     2 | 512 |   47.8 |       264.7 |
|     3 | 512 |   42.3 |      1 380.3 |
|     4 | 512 |   34.7 |     **24 379.8** |
|     5 | 512 |  **9.6** | **1 451 946.8** |

**Layer-norm timeline**: 82 → 36 → 265 → 1 380 → 24 380 → 1 451 947. Layer 5 / layer 0 = ~17 700×; layer 5 / Σ(layers 0–4) ≈ 56×. When concatenated, layer 5's values — collapsed to RankMe ≈ 10 — dwarf everything.

**RankMe** collapses from 80 (layer 1) to 10 (layer 5). Each successive layer projects onto fewer directions with larger magnitude. This is not healthy representation evolution; it is the BN+residual chain amplifying and rotating a collapsing attractor.

In isolation, **layer 0 or layer 1** (norms 82 and 36, RankMe 50–80 / 512, 0% sparsity, rotation-invariant) would be a usable REPA target — moderate rank, sane norms. The problem is the concat: it exposes only the worst slab.

## Implications for REPA training

### Do not use MC-GearNet-Edge as a REPA target in its current form

The representation is 1-dimensional with exploding norms. No projector can fit it above the mean-direction baseline (Q2), and no gradient signal can flow back to the student transformer. Any REPA run using MC-GearNet will plateau at cos-sim ≈ 0.85 on the first few steps and contribute nothing afterward — the loss curve will look *better* than CA-GearNet (higher cos-sim!) while teaching the model nothing.

### Possible fixes (not tested here)

1. **Use a single intermediate layer, not the concat.** Layer 0 or 1 has RankMe 50–80 / 512 and norms O(100). Usable REPA target.
2. **LayerNorm the per-layer slabs before concat.** Standard protocol for `concat_hidden` encoders; absent here.
3. **z-score the encoder output** inside the REPA loss (running mean/std). Addresses the symptom but not the collapse — RankMe 12 / 3072 with 95% of variance in 1 dim means standardisation alone cannot recover meaningful direction structure.
4. **Drop MC-GearNet-Edge.** CA-GearNet gives more usable REPA signal; MC's extra features (edge types, angle bins, residue identity) do not translate into representation. The simplest conclusion is that this checkpoint's output isn't designed to be consumed raw.

### Implication for `gearnet_mc_edge` config variants in the tree

`src/proteina/configs/experiment_config/training/{128,256,512}/gearnet_mc_edge/per_residue/training_repa_l{0,4,9}_*_mc_edge.yaml` all target the concatenated 3072-d output via a 3-layer projector. If any of these have been run, expect their REPA loss curves to be near-flat (or confusingly high cos-sim) and their downstream metrics to match the non-REPA baseline within noise.

## Caveats

- 200 proteins, randomised seed 0. Same sample as the other encoders so comparisons are apples-to-apples.
- SVD/probe subsampled to 30k residues for memory. Qualitative result (PR ≈ 1, 95% variance in 1 dim) is robust to sample size; the collapse is structural.
- Linear probe did not converge (`lbfgs` hit max_iter=1000). Scaling features first would likely help, but the probe is near chance anyway.
