# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.


import os
import shutil
from typing import List, Optional, Union

import einops
import torch
from jaxtyping import Float
from loguru import logger
from torch import Tensor
from transformers import AutoTokenizer, EsmForProteinFolding
from transformers import logging as hf_logging
from transformers.models.esm.openfold_utils.feats import atom14_to_atom37
from transformers.models.esm.openfold_utils.protein import Protein as OFProtein
from transformers.models.esm.openfold_utils.protein import to_pdb

from proteinfoundation.utils.align_utils.align_utils import kabsch_align_ind
from proteinfoundation.utils.ff_utils.pdb_utils import from_pdb_string

hf_logging.set_verbosity_error()


def pdb_name_from_path(pdb_file_path):
    return pdb_file_path.strip(os.sep).split(os.sep)[-1][
        :-4
    ]  # Name of the pdb file without ".pdb" extension


# ProteinMPNN
## ## ## ## ## ## ## ## ## ## ## ##


def extract_gen_seqs(path_to_file: str) -> List[str]:
    """
    Extracts sequences from ProteinMPNN generation files.

    Args:
        path_to_file: Path to file with pmpnn output.

    Returns:
        List of sequences produced by pmpnn.
    """
    seqs = []
    with open(path_to_file, "r") as f:
        first = True  # Assuming first sequence is not a generation
        for line in f:
            if not line.startswith(">"):
                if first:
                    first = False
                    continue
                else:
                    seqs.append(line.strip())
    return seqs


def run_proteinmpnn(
    pdb_file_path: str,
    out_dir_root: str,
    sampling_temp: float = 0.1,
    num_seq_per_target: int = 8,
    seed: Optional[int] = None,
    ca_only: bool = True,
    verbose: bool = False,
) -> List[str]:
    """
    Just an interfact to ProteinMPNN.

    Args:
        pdb_file_path: path to PDB file
        out_dir_root: Path used to store produced sequences
        sampling_temp: Sampling temperature for ProteinMPNN
        num_seq_per_target: Number of sequences produced per target provided
        seed: Random seed used for sampling
        ca_only: Whether to only use alpha carbons
        verbose: Print stuff or not

    Returns:
        List of sequences (strings)
    """
    name = pdb_name_from_path(pdb_file_path)

    python_exec = os.environ.get("PYTHON_EXEC")
    if python_exec is None:
        python_exec = "python"

    mpnn_dir = os.environ.get(
        "PROTEINMPNN_DIR",
        os.path.join(os.path.dirname(__file__), "..", "..", "..", "ProteinMPNN"),
    )
    mpnn_weights_root = os.environ.get("PROTEINMPNN_WEIGHTS_DIR")

    command = f"""
    {python_exec} {mpnn_dir}/protein_mpnn_run.py \
        --pdb_path {pdb_file_path} \
        --pdb_path_chains A \
        --out_folder {out_dir_root} \
        --num_seq_per_target {num_seq_per_target} \
        --sampling_temp {sampling_temp} \
        --batch_size {num_seq_per_target} \
        --suppress_print {0 if verbose else 1} \
    """

    if ca_only:
        command += " --ca_only "
        if mpnn_weights_root:
            command += f" --path_to_model_weights {mpnn_weights_root}/ca_model_weights "
    elif mpnn_weights_root:
        command += f" --path_to_model_weights {mpnn_weights_root}/vanilla_model_weights "
    if seed is not None:
        command += f" --seed {seed} "
    if not verbose:
        command += f" > /dev/null 2>&1"

    os.system(command)
    return extract_gen_seqs(os.path.join(out_dir_root, "seqs", name + ".fa"))


## ## ## ## ## ## ## ## ## ## ## ##


# ESMFold
## ## ## ## ## ## ## ## ## ## ## ##


# I got this function from hugging face's ESM notebook example
def convert_outputs_to_pdb(outputs):
    """Takes ESMFold outputs and converts them to a list of PDBs (as strings).

    Returns:
        (pdbs, plddt_means): list[str] of PDB file contents, and list[float] of
        per-sample mean pLDDT (averaged over residues/atoms).

    Note: HF `EsmForProteinFolding` returns pLDDT in the [0, 1] range, not the
    paper convention of [0, 100]. Values here are NOT scaled - consumers should
    multiply by 100 if they need the conventional pLDDT scale.
    """
    final_atom_positions = atom14_to_atom37(outputs["positions"][-1], outputs)
    outputs = {k: v.to("cpu").numpy() for k, v in outputs.items()}
    final_atom_positions = final_atom_positions.cpu().numpy()
    final_atom_mask = outputs["atom37_atom_exists"]
    pdbs = []
    plddt_means = []
    for i in range(outputs["aatype"].shape[0]):
        aa = outputs["aatype"][i]
        pred_pos = final_atom_positions[i]
        mask = final_atom_mask[i]
        resid = outputs["residue_index"][i] + 1
        plddt_i = outputs["plddt"][i]
        pred = OFProtein(
            aatype=aa,
            atom_positions=pred_pos,
            atom_mask=mask,
            residue_index=resid,
            b_factors=plddt_i,
            chain_index=outputs["chain_index"][i] if "chain_index" in outputs else None,
        )
        pdbs.append(to_pdb(pred))
        plddt_means.append(float(plddt_i.mean()))
    return pdbs, plddt_means


def load_esmfold():
    """Load ESMFold model and tokenizer.

    Returns:
        (esm_model, tokenizer) tuple. Model is on CUDA.
    """
    # TF32 matmuls give ~2.1x speedup on A100 vs the torch fp32 default (off),
    # with no measurable scRMSD/pLDDT delta. See hpc-scripts/proteina/bench/
    # benchmark_designability_bottlenecks.py (job 29435243).
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True

    is_cluster_run = os.environ.get("SLURM_JOB_ID") is not None
    cache_dir = None
    if is_cluster_run:
        cache_dir = os.environ.get("CACHE_DIR")
    tokenizer = AutoTokenizer.from_pretrained(
        "facebook/esmfold_v1", cache_dir=cache_dir
    )
    esm_model = EsmForProteinFolding.from_pretrained(
        "facebook/esmfold_v1", cache_dir=cache_dir
    )
    esm_model = esm_model.cuda()
    return esm_model, tokenizer


def run_and_store_esm(
    name: str,
    seqs: List[str],
    path_to_esmfold_out: str,
    esm_model=None,
    tokenizer=None,
):
    """
    Runs ESMFold and stores results as PDB files.

    For now, runs with a single GPU, though not a big deal if we parallelie jobs (easily
    done with our inference pipeline).

    Args:
        name: name to use when storing
        seqs: List of sequences (strings)
        path_to_esmfold_out: Root directory to store outputs of ESMFold as PDBs
        esm_model: Pre-loaded ESMFold model (optional, loads if None)
        tokenizer: Pre-loaded tokenizer (optional, loads if None)

    Returns:
        (out_esm_paths, plddt_means): list of PDB paths and list of per-sequence
        mean pLDDT values (same ordering as `seqs`).
    """
    if esm_model is None or tokenizer is None:
        esm_model, tokenizer = load_esmfold()

    # Run ESMFold
    len(seqs)
    max_nres = max([len(x) for x in seqs])
    list_of_strings_pdb = []
    list_of_plddt_means = []
    if max_nres > 700:
        batch_size = 1
        num_batches = 8
    elif max_nres > 500:
        batch_size = 2
        num_batches = 4
    else:
        batch_size = 4
        num_batches = 2

    for i in range(num_batches):
        start_idx = i * batch_size
        end_idx = start_idx + batch_size

        inputs = tokenizer(
            seqs[start_idx:end_idx],
            return_tensors="pt",
            add_special_tokens=False,
            padding=True,
        )
        inputs = {k: inputs[k].cuda() for k in inputs}

        with torch.no_grad():
            _outputs = esm_model(**inputs)

        _list_of_strings_pdb, _plddt_means = convert_outputs_to_pdb(_outputs)
        list_of_strings_pdb.extend(_list_of_strings_pdb)
        list_of_plddt_means.extend(_plddt_means)

    # Create out directory if not there
    if not os.path.exists(path_to_esmfold_out):
        os.makedirs(path_to_esmfold_out)

    # Store generations for each sequence
    out_esm_paths = []
    for i, pdb in enumerate(list_of_strings_pdb):
        fname = f"esm_{i+1}.pdb_esm"
        fdir = os.path.join(path_to_esmfold_out, fname)
        with open(fdir, "w") as f:
            f.write(pdb)
            out_esm_paths.append(fdir)
    return out_esm_paths, list_of_plddt_means


## ## ## ## ## ## ## ## ## ## ## ##


def load_pdb(fname: str) -> str:
    """Returns pdb stored in input file as string."""
    with open(fname, "r") as f:
        return from_pdb_string(f.read())


def rmsd_metric(
    coors_1_atom37: Float[Tensor, "n 37 3"],
    coors_2_atom37: Float[Tensor, "n 37 3"],
    mask_1_atom_37: Optional[Float[Tensor, "n 37"]] = None,
    mask_2_atom_37: Optional[Float[Tensor, "n 37"]] = None,
    mode: str = "ca",
    incl_ox: bool = False,
    align: bool = True,
) -> Float[Tensor, ""]:
    """
    Computes RMSD between two protein structures in the Atom37 represnetation.
    For now we only use mask to check whether we have all required atoms.

    Args:
        coors_1_atom37: First structure, shape [n, 37, 3]
        coors_2_atom37: Second structure, shape [n, 37, 3]
        mask_1_atom37: Binary mask of first structure, shape [n, 37]
        mask_2_atom37: Binary mask of first structure, shape [n, 37]
        mode: Modality to use, for now single option "ca", referring to only alpha
            carbon.
        incl_ox: Wehther to include oxygen atom, should be left to False
        align: Whether to align pointclouds before computing RMSD.

    Returns:
        RMSD value, as a Torch (float) tensor with a single element
    """
    assert coors_1_atom37.shape == coors_2_atom37.shape
    assert coors_1_atom37.shape[-1] == 3
    assert coors_1_atom37.shape[-2] == 37
    if mask_1_atom_37 is not None:
        assert mask_1_atom_37.shape == coors_1_atom37.shape[1:]
    if mask_2_atom_37 is not None:
        assert mask_2_atom_37.shape == coors_2_atom37.shape[1:]
    idx_select = [1]  # [CA]

    coors_1 = coors_1_atom37[:, idx_select, :]  # [n, natoms_sel, 3]
    coors_2 = coors_2_atom37[:, idx_select, :]  # [n, natoms_sel, 3]

    # Check all atoms actually present if we have mask
    for mask_atom_37 in [mask_1_atom_37, mask_2_atom_37]:
        if mask_atom_37 is not None:
            mask = mask_atom_37[:, idx_select]
            assert mask.sum() == mask.numel()

    # Compute RMSD (potentially) aligning structures
    coors_1 = einops.rearrange(coors_1, "n s t -> (n s) t")  # [n * natoms_sel, 3]
    coors_2 = einops.rearrange(coors_2, "n s t -> (n s) t")  # [n * natoms_sel, 3]

    if align:
        coors_1, coors_2 = kabsch_align_ind(coors_1, coors_2, ret_both=True)

    sq_err = (coors_1 - coors_2) ** 2
    return sq_err.sum(dim=-1).mean().sqrt().item()


def scRMSD(
    pdb_file_path: str,
    tmp_path: str = "./tmp/metrics/",
    num_seq_per_target: int = 8,
    pmpnn_sampling_temp: float = 0.1,
    ret_min=True,
) -> Union[float, List[float]]:
    """
    Evaluates self-consistency RMSD metrics for given pdb.

    Args:
        pdb_file_path: Path to PDB file.
        tmp_path: Path to store files produced by ProteinMPNN and ESMFold.
        num_seq_per_target: Number of sequences generated by ProteinMPNN per structure.
        pmpnn_sampling_temp: ProteinMPNN sampling temperature.
        ret_min: Whether to return min RMSD or a list of all values.

    Returns:
        Either best RMSD (scRMSD) or a list of all values for all generations, depending on
        the ret_min argument.
    """
    name = pdb_name_from_path(pdb_file_path)

    logger.info("Running ProteinMPNN")
    mpnn_gen_seqs = run_proteinmpnn(  # For now do not use keep ca_only=False
        pdb_file_path,
        tmp_path,
        num_seq_per_target=num_seq_per_target,
        sampling_temp=pmpnn_sampling_temp,
    )  # List of sequences

    logger.info(f"Running ESMFold for {name}")
    out_esm_paths, _ = run_and_store_esm(name, mpnn_gen_seqs, tmp_path)
    # List of paths to PDBs

    # Compute RMSDs
    results = []

    # Load generated
    gen_prot = load_pdb(pdb_file_path)

    # Load ESMs
    for out_esm in out_esm_paths:
        rec_prot_esm = load_pdb(out_esm)
        gen_coors = torch.Tensor(gen_prot.atom_positions)
        rec_coors = torch.Tensor(rec_prot_esm.atom_positions)

        results.append(rmsd_metric(gen_coors, rec_coors))  # rmsd_ca

    if ret_min:
        return min(results)
    return results


def batch_designability(
    pdb_paths: List[str],
    tmp_root: str = "./tmp/metrics/",
    num_seq_per_target: int = 8,
    pmpnn_sampling_temp: float = 0.1,
) -> dict:
    """Compute designability metrics for a batch of PDB files.

    Shares a single ESMFold model across all proteins for efficiency.

    Args:
        pdb_paths: List of paths to generated PDB files.
        tmp_root: Root directory for temporary files.
        num_seq_per_target: Number of ProteinMPNN sequences per structure.
        pmpnn_sampling_temp: ProteinMPNN sampling temperature.

    Returns:
        Dict with keys:
            scRMSD_list: Per-protein best scRMSD values.
            tm_score_list: Per-protein best TM-scores.
            plddt_list: Per-protein mean pLDDT of the best-scRMSD refolded sequence.
                HF ESMFold returns pLDDT in [0, 1] (not the [0, 100] paper
                convention); values are passed through unscaled.
            pdb_paths_evaluated: Subset of `pdb_paths` whose pipeline did not
                raise; aligned 1:1 with scRMSD_list / tm_score_list / plddt_list
                so callers can map path -> scRMSD (e.g. to filter diversity to
                designable backbones). May be shorter than `pdb_paths` if any
                ProteinMPNN/ESMFold call failed.
            scRMSD_mean, scRMSD_median: Aggregate RMSD stats.
            tm_score_mean: Aggregate TM-score stat.
            plddt_mean, plddt_median: Aggregate pLDDT stats (in [0, 1]).
            designability_rate: Fraction with scRMSD < 2.0 Angstrom.
    """
    from proteinfoundation.metrics.tm_score import compute_tm_score

    esm_model, tokenizer = load_esmfold()

    scRMSD_list = []
    tm_score_list = []
    plddt_list = []
    pdb_paths_evaluated = []

    for i, pdb_path in enumerate(pdb_paths):
        name = pdb_name_from_path(pdb_path)
        tmp_path = os.path.join(tmp_root, name)
        os.makedirs(tmp_path, exist_ok=True)
        logger.info(f"Designability [{i+1}/{len(pdb_paths)}]: {name}")

        try:
            # ProteinMPNN: generate sequences
            mpnn_seqs = run_proteinmpnn(
                pdb_path, tmp_path,
                num_seq_per_target=num_seq_per_target,
                sampling_temp=pmpnn_sampling_temp,
            )

            # ESMFold: fold sequences (reuse loaded model)
            esm_paths, esm_plddts = run_and_store_esm(
                name, mpnn_seqs, tmp_path,
                esm_model=esm_model, tokenizer=tokenizer,
            )

            # Compute RMSD and TM-score for each refolded structure
            gen_prot = load_pdb(pdb_path)
            gen_coors = torch.Tensor(gen_prot.atom_positions)

            best_rmsd = float("inf")
            best_tm = 0.0
            best_plddt = float("nan")  # pLDDT of the best-scRMSD refold

            for esm_path, esm_plddt in zip(esm_paths, esm_plddts):
                rec_prot = load_pdb(esm_path)
                rec_coors = torch.Tensor(rec_prot.atom_positions)

                # RMSD
                n_common = min(len(gen_coors), len(rec_coors))
                rmsd = rmsd_metric(gen_coors[:n_common], rec_coors[:n_common])
                if rmsd < best_rmsd:
                    best_rmsd = rmsd
                    best_plddt = esm_plddt

                # TM-score
                tm = compute_tm_score(
                    gen_coors[:n_common].numpy(),
                    rec_coors[:n_common].numpy(),
                )
                best_tm = max(best_tm, tm)

            scRMSD_list.append(best_rmsd)
            tm_score_list.append(best_tm)
            plddt_list.append(best_plddt)
            pdb_paths_evaluated.append(pdb_path)

        except Exception as e:
            logger.warning(f"Designability failed for {pdb_path}: {e}")
            continue
        finally:
            # Remove this PDB's ProteinMPNN/ESMFold scratch immediately. Only
            # the consolidated metrics are kept; leaving these tmp dirs behind
            # accumulates ~12 files/PDB and exhausted the /rds inode quota
            # (1M-file cap), failing the whole sweep mid-designability.
            shutil.rmtree(tmp_path, ignore_errors=True)

    # Cleanup ESMFold
    del esm_model, tokenizer
    torch.cuda.empty_cache()

    import numpy as np
    scRMSD_arr = np.array(scRMSD_list)
    tm_arr = np.array(tm_score_list)
    plddt_arr = np.array(plddt_list)

    return {
        "scRMSD_list": scRMSD_list,
        "tm_score_list": tm_score_list,
        "plddt_list": plddt_list,
        "pdb_paths_evaluated": pdb_paths_evaluated,
        "scRMSD_mean": float(scRMSD_arr.mean()) if len(scRMSD_arr) > 0 else float("nan"),
        "scRMSD_median": float(np.median(scRMSD_arr)) if len(scRMSD_arr) > 0 else float("nan"),
        "tm_score_mean": float(tm_arr.mean()) if len(tm_arr) > 0 else float("nan"),
        "plddt_mean": float(plddt_arr.mean()) if len(plddt_arr) > 0 else float("nan"),
        "plddt_median": float(np.median(plddt_arr)) if len(plddt_arr) > 0 else float("nan"),
        "designability_rate": float((scRMSD_arr < 2.0).mean()) if len(scRMSD_arr) > 0 else float("nan"),
    }
