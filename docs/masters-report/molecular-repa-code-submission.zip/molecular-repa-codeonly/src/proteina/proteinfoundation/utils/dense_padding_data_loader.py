# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

from collections import defaultdict
from collections.abc import Mapping
from typing import Any, List, Optional, Sequence, Tuple, Union

import numpy as np
import torch.utils.data
import torch_geometric
import proteinfoundation.repa.pyg_compat  # noqa: F401 - patch before torch_sparse (worker processes)
import torch_sparse
from torch.utils.data.dataloader import default_collate
from torch_geometric.data import Batch, Dataset
from torch_geometric.data.data import BaseData
from torch_geometric.data.datapipes import DatasetAdapter
from torch_geometric.data.on_disk_dataset import OnDiskDataset
from torch_geometric.data.storage import BaseStorage
from torch_geometric.typing import SparseTensor, TensorFrame, torch_frame
from torch_geometric.utils import is_sparse, is_torch_sparse_tensor
from torch_geometric.utils.sparse import cat

FLOAT_PADDING_VALUE = 1e-8
NON_FLOAT_PADDING_VALUE = -1


def _appropriate_pad_value(t: torch.Tensor) -> float:
    """Matches the per-dtype padding convention used by `_dense_pad_tensor`."""
    if torch.is_floating_point(t):
        return FLOAT_PADDING_VALUE
    if t.dtype == torch.bool:
        return 0
    return NON_FLOAT_PADDING_VALUE


def _pad_tensor_dim(t: torch.Tensor, dim: int, pad_amount: int, value: float) -> torch.Tensor:
    """Right-pad `t` along `dim` by `pad_amount` with `value` using F.pad."""
    pad = [0, 0] * t.ndim
    pos = 2 * (t.ndim - 1 - dim)  # F.pad pads from last dim backwards
    pad[pos + 1] = pad_amount
    return torch.nn.functional.pad(t, tuple(pad), mode="constant", value=value)


def _pad_dense_batch_to_target(
    batch: BaseData,
    mask_dict: Mapping,
    natural_n: int,
    target_length: int,
) -> None:
    """Post-hoc pad node-dim tensors in a collated dense batch from `natural_n` to
    `target_length`.

    Node-dim tensors are identified by the shape signal `t.shape[1] == natural_n`
    (dim 0 is batch). This avoids touching non-node-dim tensors (e.g., edge_index,
    per-sample scalars) while cleanly extending per-residue features to the
    target length.

    Mutates `batch` and `mask_dict` in place.
    """
    if target_length == natural_n:
        return
    assert target_length > natural_n, (
        f"target_length={target_length} must be >= natural_n={natural_n}"
    )
    pad_amount = target_length - natural_n

    def maybe_pad(t: Any, pad_value: float) -> Any:
        if not isinstance(t, torch.Tensor) or t.ndim < 2 or t.size(1) != natural_n:
            return t
        return _pad_tensor_dim(t, dim=1, pad_amount=pad_amount, value=pad_value)

    for store in batch.stores:
        for attr in list(store.keys()):
            val = store[attr]
            if isinstance(val, torch.Tensor):
                store[attr] = maybe_pad(val, _appropriate_pad_value(val))

    for k, v in list(mask_dict.items()):
        if isinstance(v, Mapping):
            for kk, vv in list(v.items()):
                if isinstance(vv, torch.Tensor):
                    mask_dict[k][kk] = maybe_pad(vv, 0)
        elif isinstance(v, torch.Tensor):
            mask_dict[k] = maybe_pad(v, 0)


def _num_nodes_of(d: BaseData) -> int:
    """Return residue count for a PyG Data object. PyG's `Data.num_nodes` is a
    lazily-inferred property that returns None when no recognized node-dim
    attribute is present; fall back to `coords.shape[0]` (the canonical
    node-dim tensor in proteina graphs)."""
    n = d.num_nodes
    if n is not None:
        return int(n)
    coords = d.get("coords") if hasattr(d, "get") else getattr(d, "coords", None)
    if coords is None:
        raise ValueError(
            "Data object has neither num_nodes nor coords - can't determine bucket."
        )
    return int(coords.shape[0])


def _target_length_for_batch(
    data_list: List[BaseData], bucket_boundaries: Optional[Sequence[int]]
) -> Optional[int]:
    """Given a batch of PyG Data objects and optional bucket boundaries, return the
    padding target (smallest boundary >= batch's max num_nodes). Returns None when
    boundaries are not configured - caller should skip bucket-max padding.
    """
    if bucket_boundaries is None:
        return None
    batch_max = max(_num_nodes_of(d) for d in data_list)
    candidates = [b for b in bucket_boundaries if b >= batch_max]
    if not candidates:
        raise ValueError(
            f"Batch contains a sample with num_nodes={batch_max} that exceeds the "
            f"largest bucket boundary {max(bucket_boundaries)}."
        )
    return int(min(candidates))


def _dense_pad_tensor(
    key,
    values,
    float_padding_value: float = FLOAT_PADDING_VALUE,
    non_float_padding_value: int = NON_FLOAT_PADDING_VALUE,
) -> Tuple[Any, Any]:
    """Densely pads a list of `torch.Tensor` along a new `batch_dim=0`.

    Args:
        key (str): The key of the attribute to be padded.
        values (list): A list of values to be padded.
        float_padding_value (float, optional): The padding value for `float` dtype tensors.
        non_float_padding_value (int, optional): The padding value for non-`float` (e.g., `int`) dtype tensors.

    Returns:
        A tuple containing the padded value and an optional mask.
    """
    mask = None
    cat_dim = None
    elem = values[0]
    dtype = elem.dtype
    padding_value = (
        float_padding_value
        if torch.is_floating_point(elem)
        else non_float_padding_value
    )
    if elem.dim() == 0:
        values = [value.unsqueeze(0) for value in values]
    else:
        if dtype != torch.float:
            if dtype in [torch.uint8, torch.bool]:
                # NOTE: We cannot use `torch.nn.utils.rnn.pad_sequence` directly with unsigned integer/boolean tensors.
                values = [value.long() for value in values]
            if "edge_index" in key and elem.dim() == 2 and elem.shape[0] == 2:
                # Concatenate `edge_index` tensors.
                # NOTE: Here, we assume dimension `0` denotes the source and target node indices and dimension `1` denotes the number of edges.
                values = [
                    value.permute(1, 0).unsqueeze(0)
                    for value in torch.nn.utils.rnn.pad_sequence(
                        [val.permute(1, 0) for val in values],
                        batch_first=True,
                        padding_value=padding_value,
                    )
                ]
            else:
                values = [
                    value.unsqueeze(0)
                    for value in torch.nn.utils.rnn.pad_sequence(
                        values, batch_first=True, padding_value=padding_value
                    )
                ]
            if dtype in [torch.uint8, torch.bool]:
                # NOTE: We cannot use `torch.nn.utils.rnn.pad_sequence` directly with unsigned integer/boolean tensors.
                mask = torch.cat(
                    [(value != padding_value) for value in values], dim=cat_dim or 0
                )
                for value in values:
                    value[value == padding_value] = 0
                values = [value.to(dtype) for value in values]
        else:
            values = [
                value.unsqueeze(0)
                for value in torch.nn.utils.rnn.pad_sequence(
                    values, batch_first=True, padding_value=padding_value
                )
            ]

    return values, mask


def _dense_padded_collate(
    key: str,
    values: List[Any],
    data_list: List[BaseData],
    stores: List[BaseStorage],
    float_padding_value: float = FLOAT_PADDING_VALUE,
    non_float_padding_value: int = NON_FLOAT_PADDING_VALUE,
) -> Tuple[Any, Any]:
    """Collates a list of values into a single tensor or list of tensors.

    Args:
        key (str): The key of the attribute to be collated.
        values (list): A list of values to be collated.
        data_list (list): A list of data objects.
        stores (list): A list of storage objects.
        float_padding_value (float, optional): The padding value for `float` dtype tensors.
        non_float_padding_value (int, optional): The padding value for non-`float` (e.g., `int`) dtype tensors.

    Returns:
        A tuple containing the collated value and an optional mask.
    """
    cat_dim = None
    elem = values[0]

    if isinstance(elem, torch.Tensor) and not is_sparse(elem):
        # Concatenate a list of `torch.Tensor` along a new `batch_dim=0`.
        padding_value = (
            float_padding_value
            if torch.is_floating_point(elem)
            else non_float_padding_value
        )
        values, mask = _dense_pad_tensor(
            key,
            values,
            float_padding_value=float_padding_value,
            non_float_padding_value=non_float_padding_value,
        )

        if getattr(elem, "is_nested", False):
            raise NotImplementedError(
                "Dense padding collation for nested tensors is not supported (tested) yet."
            )

        out = None
        if torch.utils.data.get_worker_info() is not None:
            # Write directly into shared memory to avoid an extra copy:
            numel = sum(value.numel() for value in values)
            if torch_geometric.typing.WITH_PT20:
                storage = elem.untyped_storage()._new_shared(
                    numel * elem.element_size(), device=elem.device
                )
            elif torch_geometric.typing.WITH_PT112:
                storage = elem.storage()._new_shared(numel, device=elem.device)
            else:
                storage = elem.storage()._new_shared(numel)
            shape = [len(data_list)] + list(
                values[np.argmax([value.numel() for value in values])].shape[1:]
            )
            out = elem.new(storage).resize_(shape)

        value = torch.cat(values, dim=cat_dim or 0, out=out)
        mask = mask if mask is not None else (value != padding_value)

        return value, mask

    elif isinstance(elem, TensorFrame):
        raise NotImplementedError(
            "Dense padding collation for TensorFrames is not supported (tested) yet."
        )

    elif is_sparse(elem):
        # Concatenate a list of `SparseTensor` along the `cat_dim`.
        raise NotImplementedError(
            "Dense padding collation for SparseTensors is not supported (tested) yet."
        )

    elif isinstance(elem, (int, float)):
        # Convert a list of numerical values to a `torch.Tensor`.
        value = torch.tensor(values)
        return value, None

    elif isinstance(elem, Mapping):
        # Recursively collate elements of dictionaries.
        value_dict, mask_dict = {}, {}
        for key in elem.keys():
            value_dict[key], mask_dict[key] = _dense_padded_collate(
                key, [v[key] for v in values], data_list, stores
            )
        return value_dict, mask_dict

    elif (
        isinstance(elem, Sequence)
        and not isinstance(elem, str)
        and len(elem) > 0
        and isinstance(elem[0], (torch.Tensor, SparseTensor))
    ):
        # Recursively collate elements of lists.
        value_list, mask_list = [], []
        for i in range(len(elem)):
            value, mask = _dense_padded_collate(
                key, [v[i] for v in values], data_list, stores
            )
            value_list.append(value)
            mask_list.append(mask)
        return value_list, mask_list

    else:
        # Other-wise, just return the list of values as it is.
        return values, None


def dense_padded_collate(
    cls,
    data_list: List[BaseData],
    follow_batch: Optional[List[str]] = None,
    exclude_keys: Optional[List[str]] = None,
) -> Tuple[BaseData, Mapping]:
    """Collates a list of `data` objects into a single dense object of type `cls`. `collate` can
    handle both homogeneous and heterogeneous data objects by individually collating all their
    stores. In addition, `collate` can handle nested data structures such as dictionaries and
    lists.

    Args:
        cls (type): The class into which to collate.
        data_list (list): A list of data objects.
        follow_batch (list, optional): Creates assignment batch vectors for
            each key in the list. (default: `None`)
        exclude_keys (list, optional): Will exclude each key in the list.
            (default: `None`)

    Returns:
        A tuple containing the collated data object and a dictionary
        holding optional batch feature masks.
    """
    if not isinstance(data_list, (list, tuple)):
        # Materialize `data_list` to keep the `_parent` weakref alive.
        data_list = list(data_list)

    if cls != data_list[0].__class__:
        out = cls(_base_cls=data_list[0].__class__)  # Dynamic inheritance.
    else:
        out = cls()

    # Create empty stores:
    out.stores_as(data_list[0])

    follow_batch = set(follow_batch or [])
    exclude_keys = set(exclude_keys or [])

    # Group all storage objects of every data object in the `data_list` by key,
    # i.e. `key_to_store_list = { key: [store_1, store_2, ...], ... }`:
    key_to_stores = defaultdict(list)
    for data in data_list:
        for store in data.stores:
            key_to_stores[store._key].append(store)

    # With this, we iterate over each list of storage objects and recursively
    # collate all its attributes into a unified representation:

    # We maintain an additional dictionary:
    # * `mask_dict` stores a mask representation of each attribute
    #    and is needed to re-construct individual elements from mini-batches.
    mask_dict = defaultdict(dict)
    for out_store in out.stores:
        key = out_store._key
        stores = key_to_stores[key]
        for attr in stores[0].keys():
            if attr in exclude_keys:  # Do not include top-level attribute.
                continue

            values = [store[attr] for store in stores]

            # The `num_nodes` attribute needs special treatment, as we need to
            # sum their values up instead of merging them to a list:
            if attr == "num_nodes":
                out_store._num_nodes = values
                out_store.num_nodes = sum(values)
                continue

            # Skip batching of `ptr` vectors during dense collation:
            if attr == "ptr":
                continue

            # Collate attributes into a unified representation:
            value, mask = _dense_padded_collate(attr, values, data_list, stores)

            out_store[attr] = value
            if mask is not None:
                if key is not None:
                    mask_dict[key][attr] = mask
                else:
                    mask_dict[attr] = mask

    return out, mask_dict


def dense_padded_from_data_list(
    data_list: List[BaseData],
    follow_batch: Optional[List[str]] = None,
    exclude_keys: Optional[List[str]] = None,
    bucket_boundaries: Optional[Sequence[int]] = None,
):
    r"""Constructs a dense `~torch_geometric.data.Batch` object from a Python list of
    `~torch_geometric.data.Data` or `~torch_geometric.data.HeteroData` objects. The assignment
    vector `batch` is created on the fly. In addition, creates assignment vectors for each key in
    `follow_batch`. Will exclude any keys given in `exclude_keys`.

    Args:
        data_list (list): A list of data objects.
        follow_batch (list, optional): Creates assignment batch vectors for
            each key in the list. (default: `None`)
        exclude_keys (list, optional): Will exclude each key in the list.
            (default: `None`)
        bucket_boundaries (Sequence[int], optional): If provided, node-dim tensors
            are padded to the smallest boundary >= max(num_nodes) in the batch.
            Enables fixed `(B, N)` shapes per bucket so `torch.compile` caches
            one graph per bucket. When None (default), padding is batch-max.

    Returns:
        A single `Batch` object holding a mini-batch of data. When
        `bucket_boundaries` is provided, also sets `batch.bucket_length` to the
        padded residue dimension.
    """
    batch, mask_dict = dense_padded_collate(
        Batch,
        data_list=data_list,
        follow_batch=follow_batch,
        exclude_keys=exclude_keys,
    )

    batch._num_graphs = len(data_list)

    target_length = _target_length_for_batch(data_list, bucket_boundaries)
    if target_length is not None:
        natural_n = max(_num_nodes_of(d) for d in data_list)
        _pad_dense_batch_to_target(batch, mask_dict, natural_n, target_length)
        batch.bucket_length = target_length

    batch.mask_dict = mask_dict  # NOTE: `mask_dict` must be a public attribute of `Batch` for auto-device onloading to work.

    return batch


class DensePaddingCollater:
    """Collates data objects from a `torch_geometric.data.Dataset` to a mini-batch using padding
    along with a new dimension.

    Data objects can be
    either of type `~torch_geometric.data.Data` or
    `~torch_geometric.data.HeteroData`.

    When `bucket_boundaries` is provided, node-dim tensors are padded to the
    smallest boundary >= max(num_nodes) in the batch rather than the batch max.
    Combined with a length-bucketed sampler this yields fixed `(B, N)` shapes
    per bucket so `torch.compile` caches one graph per bucket.
    """

    def __init__(
        self,
        dataset: Union[Dataset, Sequence[BaseData], DatasetAdapter],
        follow_batch: Optional[List[str]] = None,
        exclude_keys: Optional[List[str]] = None,
        bucket_boundaries: Optional[Sequence[int]] = None,
    ):
        self.dataset = dataset
        self.follow_batch = follow_batch
        self.exclude_keys = exclude_keys
        self.bucket_boundaries = (
            list(bucket_boundaries) if bucket_boundaries is not None else None
        )

    def __call__(self, batch: List[Any]) -> Any:
        """Collates a python list of data objects to the internal storage format of
        `torch_geometric.data.DataLoader`.

        Args:
            batch: A python list of data objects.

        Returns:
            A mini-batch of data objects.
        """
        elem = batch[0]
        if isinstance(elem, BaseData):
            # Backward-compat: use getattr so instances pickled from pre-bucketing
            # code (no `bucket_boundaries` in __dict__) fall back to None =
            # non-bucketed behavior when unpickled by a worker running newer code.
            # See feedback_collator_hotreload.md for the incident that motivated this.
            return dense_padded_from_data_list(
                batch,
                follow_batch=self.follow_batch,
                exclude_keys=self.exclude_keys,
                bucket_boundaries=getattr(self, "bucket_boundaries", None),
            )
        elif isinstance(elem, torch.Tensor):
            return default_collate(batch)
        elif isinstance(elem, TensorFrame):
            return torch_frame.cat(batch, along="row")
        elif isinstance(elem, float):
            return torch.tensor(batch, dtype=torch.float)
        elif isinstance(elem, int):
            return torch.tensor(batch)
        elif isinstance(elem, str):
            return batch
        elif isinstance(elem, Mapping):
            return {key: self([data[key] for data in batch]) for key in elem}
        elif isinstance(elem, tuple) and hasattr(elem, "_fields"):
            return type(elem)(*(self(s) for s in zip(*batch)))
        elif isinstance(elem, Sequence) and not isinstance(elem, str):
            return [self(s) for s in zip(*batch)]

        raise TypeError(f"DataLoader found invalid type: '{type(elem)}'")

    def collate_fn(self, batch: List[Any]) -> Any:
        """Collates a python list of data objects to the internal storage format of
        `torch_geometric.data.DataLoader`.

        Args:
            batch: A python list of data objects.

        Returns:
            A mini-batch of data objects.
        """
        if isinstance(self.dataset, OnDiskDataset):
            return self(self.dataset.multi_get(batch))
        return self(batch)


class DensePaddingDataLoader(torch.utils.data.DataLoader):
    r"""A data loader which merges data objects from a `torch_geometric.data.Dataset` to a mini-
    batch using padding along with a new dimension. Data objects can be either of type
    `~torch_geometric.data.Data` or `~torch_geometric.data.HeteroData`.

    Args:
        dataset (Dataset): The dataset from which to load the data.
        batch_size (int, optional): How many samples per batch to load.
            (default: `1`)
        shuffle (bool, optional): If set to `True`, the data will be
            reshuffled at every epoch. (default: `False`)
        follow_batch (List[str], optional): Creates assignment batch
            vectors for each key in the list. (default: `None`)
        exclude_keys (List[str], optional): Will exclude each key in the
            list. (default: `None`)
        **kwargs (optional): Additional arguments of
            `torch.utils.data.DataLoader`.
    """

    def __init__(
        self,
        dataset: Union[Dataset, Sequence[BaseData], DatasetAdapter],
        batch_size: int = 1,
        shuffle: bool = False,
        follow_batch: Optional[List[str]] = None,
        exclude_keys: Optional[List[str]] = None,
        bucket_boundaries: Optional[Sequence[int]] = None,
        **kwargs,
    ):
        # Remove for PyTorch Lightning:
        kwargs.pop("collate_fn", None)

        # Save for PyTorch Lightning < 1.6:
        self.follow_batch = follow_batch
        self.exclude_keys = exclude_keys

        self.collator = DensePaddingCollater(
            dataset, follow_batch, exclude_keys, bucket_boundaries=bucket_boundaries
        )

        if isinstance(dataset, OnDiskDataset):
            dataset = range(len(dataset))

        super().__init__(
            dataset,
            batch_size,
            shuffle,
            collate_fn=self.collator.collate_fn,
            **kwargs,
        )
