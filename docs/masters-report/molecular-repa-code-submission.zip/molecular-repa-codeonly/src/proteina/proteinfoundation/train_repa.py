"""Training script for Proteina with optional REPA alignment.

Minimal modification of train.py: uses ProteinaREPA when a `repa` config
section is present, otherwise falls back to standard Proteina.
"""

import os
import sys

root = os.path.abspath(".")
sys.path.append(root)
# graphein_utils lives at src/proteina/graphein_utils/ (sibling to proteinfoundation/)
sys.path.append(os.path.abspath(".."))

# Patch torch_scatter/torch_sparse with native PyTorch ops if C extensions
# don't work (common on HPC clusters with GLIBC < 2.32 or ABI mismatches).
# Must happen before any proteina imports.
import proteinfoundation.repa.pyg_compat  # noqa: F401, E402


import argparse
import json
import pickle
from pathlib import Path

import hydra
import lightning as L
import loralib as lora
import torch
import wandb
from dotenv import load_dotenv
from lightning.pytorch.loggers import WandbLogger
from lightning.pytorch.utilities import rank_zero_only
from loguru import logger
from omegaconf import OmegaConf

from proteinfoundation.proteinflow.proteina import Proteina
from proteinfoundation.repa.proteina_repa import ProteinaREPA
from proteinfoundation.utils.ema_utils.ema_callback import EMA, EmaModelCheckpoint
from proteinfoundation.utils.fetch_last_ckpt import fetch_last_ckpt
from proteinfoundation.utils.lora_utils import replace_lora_layers
from proteinfoundation.utils.metric_utils import (
    transform_global_percentage_to_mask_dropout,
)
from proteinfoundation.utils.seed_callback import SeedCallback
from proteinfoundation.utils.training_analysis_utils import (
    GradAndWeightAnalysisCallback,
    LogEpochTimeCallback,
    LogSetpTimeCallback,
    SkipNanGradCallback,
)


@rank_zero_only
def log_info(msg):
    logger.info(msg)


@rank_zero_only
def store_configs(path_configs):
    for cfg, path in path_configs:
        with open(path, "w") as f:
            cfg_aux = OmegaConf.to_container(cfg, resolve=True)
            json.dump(cfg_aux, f, indent=4, sort_keys=True)


@rank_zero_only
def log_configs(path_configs, wandb_logger):
    if wandb_logger is None:
        return
    artifact = wandb.Artifact(f"config_files_{run_name}", type="config")
    for _, path in path_configs:
        artifact.add_file(path)
    wandb_logger.experiment.log_artifact(artifact)


@rank_zero_only
def create_dir(checkpoint_path_store, parents=True, exist_ok=True):
    Path(checkpoint_path_store).mkdir(parents=parents, exist_ok=exist_ok)


if __name__ == "__main__":

    load_dotenv()

    parser = argparse.ArgumentParser(description="Job info")
    parser.add_argument(
        "--config_name",
        type=str,
        default="training_ca",
        help="Name of the config yaml file.",
    )
    parser.add_argument(
        "--nolog",
        action="store_true",
        help="Avoids checkpoints and wandb logging, mostly for debugging.",
    )
    parser.add_argument(
        "--single", action="store_true", help="Sets single node and single GPU, ignoring config file."
    )
    parser.add_argument(
        "--show_prog_bar",
        action="store_true",
        help="Shows progress bar as training progresses.",
    )
    parser.add_argument(
        "--config_subdir",
        type=str,
        default=None,
        help="Subdirectory under experiment_config/ (e.g. 'training/256').",
    )
    parser.add_argument(
        "--max_steps",
        type=int,
        default=-1,
        help="Lightning Trainer max_steps. -1 (default) means unlimited; use a small value (e.g. 100) for smoke runs.",
    )
    parser.add_argument(
        "--no_compile",
        action="store_true",
        help="Disable torch.compile regardless of config (useful for smoke tests).",
    )
    parser.add_argument(
        "--batch_size",
        type=int,
        default=None,
        help="Override datamodule batch_size (useful for OOM debugging / memory sweeps).",
    )
    args = parser.parse_args()

    logger.add(
        sys.stdout,
        format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {file}:{line} | {message}",
    )
    log_info(f"Avoid wandb and checkpointing: {args.nolog}")
    callbacks = [SeedCallback()]

    # Load experiment config
    config_path = "../configs/experiment_config"
    config_name = f"{args.config_subdir}/{args.config_name}" if args.config_subdir else args.config_name
    with hydra.initialize(config_path, version_base=hydra.__version__):
        cfg_exp = hydra.compose(config_name=config_name)
        if args.single:
            cfg_exp.hardware.ngpus_per_node_ = 1
            cfg_exp.hardware.nnodes_ = 1
            cfg_exp.run_name_ = cfg_exp.run_name_ + "_single"
        log_info(f"Exp config {cfg_exp}")

    # Set training precision
    precision = "32"
    if not cfg_exp.force_precision_f32:
        log_info("Using mixed precision")
        torch.set_float32_matmul_precision("medium")
        precision = "bf16-mixed"

    # Set training fold labels dropout rate based on global percentage
    if cfg_exp.training.get("fold_label_sample_ratio") is not None:
        log_info("Setting fold label dropout rate based on fold_label_sample_ratio")
        (
            cfg_exp.training.mask_T_prob,
            cfg_exp.training.mask_A_prob,
            cfg_exp.training.mask_C_prob,
        ) = transform_global_percentage_to_mask_dropout(
            cfg_exp.training.fold_label_sample_ratio
        )
        log_info(
            "Set mask_T_prob: %.3f, mask_A_prob: %.3f, mask_C_prob: %.3f"
            % (
                cfg_exp.training.mask_T_prob,
                cfg_exp.training.mask_A_prob,
                cfg_exp.training.mask_C_prob,
            )
        )

    # Set run name and root directory
    run_name = cfg_exp.run_name_
    log_info(f"Job name: {run_name}")
    # Resolve symlinks upfront (`store` is a symlink /home/...-> /rds/...) so
    # Lightning's atomic_save doesn't straddle filesystems when it falls back
    # from os.rename to copyfile. Without this the temp->final move trips
    # "Invalid cross-device link" -> sendfile -> spurious disk-quota errors.
    root_run = os.path.realpath(os.path.join(".", "store", run_name))
    log_info(f"Root run: {root_run}")

    # Set checkpoint directory
    checkpoint_path_store = os.path.join(root_run, "checkpoints")
    log_info(f"Checkpoints directory: {checkpoint_path_store}")

    # Check for existing checkpoint (resume support)
    last_ckpt_name = fetch_last_ckpt(checkpoint_path_store)
    last_ckpt_path = (
        os.path.join(checkpoint_path_store, last_ckpt_name)
        if last_ckpt_name is not None
        else None
    )
    log_info(f"Last checkpoint: {last_ckpt_path}")

    num_cpus = cfg_exp.hardware.ncpus_per_task_train_
    log_info(f"Number of CPUs per task: {num_cpus}")

    if last_ckpt_path is None:
        log_info(f"Seeding everything to seed {cfg_exp.seed}")
        L.seed_everything(cfg_exp.seed)

    # Load data config
    dataset_config_subdir = cfg_exp.get("dataset_config_subdir", None)
    if dataset_config_subdir is not None:
        config_path = f"../configs/datasets_config/{dataset_config_subdir}"
    else:
        config_path = "../configs/datasets_config/"
    with hydra.initialize(config_path, version_base=hydra.__version__):
        cfg_data = hydra.compose(config_name=cfg_exp["dataset"])
        cfg_data.datamodule.num_workers = min(num_cpus, cfg_data.datamodule.num_workers)
        if args.batch_size is not None:
            cfg_data.datamodule.batch_size = args.batch_size
            log_info(f"Overriding batch_size to {args.batch_size}")
        if cfg_data.get("exclude_id_pkl_path") is not None:
            with open(cfg_data.exclude_id_pkl_path, "rb") as fin:
                exclude_ids = pickle.load(fin)
            if cfg_data.datamodule.dataselector.exclude_ids is not None:
                cfg_data.datamodule.dataselector.exclude_ids += exclude_ids
            else:
                cfg_data.datamodule.dataselector.exclude_ids = exclude_ids
        log_info(f"Data config {cfg_data}")

    datamodule = hydra.utils.instantiate(cfg_data.datamodule)

    # Set logger
    wandb_logger = None
    if cfg_exp.log.log_wandb and not args.nolog:
        from datetime import datetime

        display_name = f"{datetime.now().strftime('%m%d-%H%M')}-{run_name}"
        # Log LMDB source (nvme vs lustre) for storage performance comparison
        lmdb_dir = os.environ.get("LMDB_DIR", "unknown")
        lmdb_source = "nvme" if "/tmp/" in lmdb_dir else "lustre"

        # Derive encoder type for WandB tag + group - mirrors the resolution
        # order used by _build_encoder() so the tag matches what's instantiated.
        repa_cfg = cfg_exp.get("repa")
        if repa_cfg is None:
            encoder_type = "baseline"
        elif repa_cfg.get("encoder") is not None:
            encoder_type = repa_cfg.encoder.type
        else:
            encoder_type = "gearnet"  # legacy (flat repa.gearnet_ckpt_path) -> gearnet

        wandb_logger = WandbLogger(
            project=cfg_exp.log.wandb_project,
            id=run_name,
            name=display_name,
            resume="allow",
            tags=[f"lmdb_{lmdb_source}", f"encoder_{encoder_type}"],
            group=f"encoder_{encoder_type}",
        )
        callbacks.append(LogEpochTimeCallback())
        callbacks.append(LogSetpTimeCallback())

    log_info(f"Using EMA with decay {cfg_exp.ema.decay}")
    callbacks.append(EMA(**cfg_exp.ema))

    # Set checkpointing
    if cfg_exp.log.checkpoint and not args.nolog:
        args_ckpt_last = {
            "dirpath": checkpoint_path_store,
            "save_weights_only": False,
            "filename": "ignore",
            "every_n_train_steps": cfg_exp.log.last_ckpt_every_n_steps,
            "save_last": True,
        }
        args_ckpt = {
            "dirpath": checkpoint_path_store,
            "save_last": False,
            "save_weights_only": False,
            "filename": "chk_{epoch:08d}_{step:012d}",
            "every_n_train_steps": cfg_exp.log.checkpoint_every_n_steps,
            "monitor": "train/trans_loss",
            "save_top_k": 10000,
            "mode": "min",
        }
        checkpoint_callback = EmaModelCheckpoint(**args_ckpt)
        checkpoint_callback_last = EmaModelCheckpoint(**args_ckpt_last)

        create_dir(checkpoint_path_store, parents=True, exist_ok=True)
        callbacks.append(checkpoint_callback)
        callbacks.append(checkpoint_callback_last)

        path_configs = [
            (cfg_data, os.path.join(checkpoint_path_store, f"data_config_{run_name}.json")),
            (cfg_exp, os.path.join(checkpoint_path_store, f"exp_config_{run_name}.json")),
        ]
        store_configs(path_configs)
        log_configs(path_configs, wandb_logger)

    if cfg_exp.opt.grad_and_weight_analysis:
        callbacks.append(GradAndWeightAnalysisCallback())
    if cfg_exp.opt.skip_nan_grad:
        callbacks.append(SkipNanGradCallback())

    # Length-bucketed training: mutate trainer.accumulate_grad_batches per
    # batch so effective optimizer-step BS is ~constant across buckets. See
    # docs/research/proteina_training_runs.md ("Length-bucketed training").
    if cfg_data.datamodule.get("sampling_mode") == "length-bucketed":
        from proteinfoundation.callbacks.per_bucket_grad_accum import (
            PerBucketGradAccumCallback,
        )

        bucket_boundaries = list(cfg_data.datamodule.bucket_boundaries)
        bucket_batch_sizes = list(cfg_data.datamodule.bucket_batch_sizes)
        target_effective_bs = cfg_exp.opt.get(
            "target_effective_bs", max(bucket_batch_sizes)
        )
        callbacks.append(
            PerBucketGradAccumCallback(
                bucket_boundaries=bucket_boundaries,
                bucket_batch_sizes=bucket_batch_sizes,
                target_effective_bs=target_effective_bs,
            )
        )
        log_info(
            f"Length-bucketed training: boundaries={bucket_boundaries}, "
            f"bucket_bs={bucket_batch_sizes}, target_effective_bs={target_effective_bs}"
        )

    # Generation quality evaluation callback.
    # NOT IN USE — disabled globally (eval_callback.enabled: false in all
    # training configs). Hangs multi-GPU DDP runs: rank 0 spends ~30 min on
    # GearNet scoring while rank 1 sits on the next all_reduce, tripping the
    # NCCL watchdog. Kept around in case we want offline eval later; if
    # re-enabling, gate the rank-0 path with `trainer.strategy.barrier()`.
    eval_cb_cfg = cfg_exp.get("eval_callback")
    if eval_cb_cfg is not None and eval_cb_cfg.get("enabled", False):
        from proteinfoundation.callbacks.generation_metrics import ProteinGenerationMetricsCallback
        eval_cb_kwargs = {k: v for k, v in eval_cb_cfg.items() if k != "enabled"}
        callbacks.append(ProteinGenerationMetricsCallback(**eval_cb_kwargs))
        log_info(f"Generation metrics callback enabled (every {eval_cb_cfg.get('compute_every_n_steps', '?')} steps)")

    # === KEY CHANGE: Use ProteinaREPA if repa config is present ===
    use_repa = cfg_exp.get("repa") is not None
    if use_repa:
        log_info("REPA config detected - using ProteinaREPA model")
        log_info(f"REPA layers: {cfg_exp.repa.layers}, lambda: {cfg_exp.repa.lambda_repa}")
        model = ProteinaREPA(cfg_exp, store_dir=root_run)
    else:
        log_info("No REPA config - using standard Proteina model")
        model = Proteina(cfg_exp, store_dir=root_run)

    # LoRA support
    if cfg_exp.get("lora") and cfg_exp.lora.get("r"):
        replace_lora_layers(
            model, cfg_exp.lora.r, cfg_exp.lora.lora_alpha, cfg_exp.lora.lora_dropout
        )
        lora.mark_only_lora_as_trainable(model, bias=cfg_exp.lora.train_bias)

    # Pre-trained checkpoint loading
    pretrain_ckpt_path = cfg_exp.get("pretrain_ckpt_path", None)
    if last_ckpt_path is None and pretrain_ckpt_path is not None:
        log_info(f"Loading from pre-trained checkpoint path {pretrain_ckpt_path}")
        ckpt = torch.load(pretrain_ckpt_path, map_location="cpu", weights_only=False)
        model.load_state_dict(ckpt["state_dict"], strict=False)

    # torch.compile for faster training (requires constant tensor shapes via PaddingTransform)
    if cfg_exp.get("compile", False) and not args.no_compile:
        # Length-bucketed training sees a small, fixed set of (B, N) shapes (one per
        # bucket). Force dynamic=False so each bucket gets its own static graph
        # instead of Dynamo's automatic_dynamic path, which switches to symbolic
        # shapes on the second distinct shape and can trip Inductor on ops with
        # additive shape offsets (e.g. num_registers=10 -> `s2 + 10`). P2 verified
        # static compilation works cleanly across all 4 bucket shapes.
        bucketed = cfg_data.datamodule.get("sampling_mode") == "length-bucketed"
        dyn = False if bucketed else None
        if bucketed:
            # 4 bucket shapes x >=2 dtype contexts (bf16 autocast in train vs
            # float32 in some call sites) x a few resume frames easily exceeds
            # Dynamo's default recompile cache size (8). Once the cache fills,
            # Dynamo silently falls back to eager for those frames, defeating
            # the speed-up. 32 gives ~4x headroom.
            import torch._dynamo as _dynamo
            _dynamo.config.recompile_limit = 32
            log_info(f"Set torch._dynamo.config.recompile_limit = 32 (bucketed)")
        log_info(f"Compiling model.nn with torch.compile (mode=default, dynamic={dyn})")
        model.nn = torch.compile(model.nn, dynamic=dyn)

        # Also compile the REPA encoder if present. Always dynamic=True: GearNet
        # graph construction (radius_graph, unique_consecutive, repeat_interleave)
        # produces data-dependent shapes that change with sequence length / batch
        # composition. fullgraph=False allows graph breaks at Python control flow
        # in the compat shim so the GNN layers still get fused.
        if hasattr(model, "repa_loss") and hasattr(model.repa_loss, "encoder"):
            log_info("Compiling repa_loss.encoder with torch.compile (dynamic=True, fullgraph=False)")
            model.repa_loss.encoder = torch.compile(
                model.repa_loss.encoder, dynamic=True, fullgraph=False
            )

    # Train
    plugins = []
    show_prog_bar = args.show_prog_bar
    trainer = L.Trainer(
        max_epochs=cfg_exp.opt.max_epochs,
        max_steps=args.max_steps,
        accelerator=cfg_exp.hardware.accelerator,
        devices=cfg_exp.hardware.ngpus_per_node_,
        num_nodes=cfg_exp.hardware.nnodes_,
        callbacks=callbacks,
        logger=wandb_logger,
        log_every_n_steps=cfg_exp.opt.log_every_n_steps,
        default_root_dir=root_run,
        check_val_every_n_epoch=None,
        val_check_interval=cfg_exp.opt.val_check_interval,
        strategy=cfg_exp.opt.dist_strategy,
        enable_progress_bar=show_prog_bar,
        plugins=plugins,
        accumulate_grad_batches=cfg_exp.opt.accumulate_grad_batches,
        num_sanity_val_steps=1,
        precision=precision,
        gradient_clip_algorithm="norm",
        gradient_clip_val=1.0,
        use_distributed_sampler=(cfg_data.datamodule.get("sampling_mode") != "length-bucketed"),
        enable_checkpointing=not args.nolog,
    )
    trainer.fit(model, datamodule, ckpt_path=last_ckpt_path, weights_only=False)
