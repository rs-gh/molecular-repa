# Data directory

The QM9 and GEOM LMDB datasets used for training are not included in this
submission (multi-GB). Place the processed LMDBs here:

    data/lmdb_qm9/
    data/lmdb_geom/

See the top-level README for dataset preparation.
