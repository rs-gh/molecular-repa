# Licensing notice

This project combines code under two different licenses. Redistribution and
use are governed by the **most restrictive** applicable terms.

## Summary

| Component | Origin | License |
|---|---|---|
| `src/proteina/` | Fork of NVIDIA Proteina | **NVIDIA License** — non-commercial, research/evaluation only |
| `src/tabasco/` | Fork of Tabasco (Carlos Vonessen) | MIT |
| `evaluation/`, `encoder_profiling/`, `tests/`, training scripts | Original work by the author | Treated as NVIDIA-License derivative (see below) |

## Why the whole project is non-commercial

`src/proteina/` is a **derivative work** of NVIDIA Proteina: it directly
modifies NVIDIA's source. Under the NVIDIA License (§3.1, §3.2), the fork must
remain under that license, and any derivative works carry the non-commercial
use limitation (§3.3: "for research or evaluation purposes only").

The author's `evaluation/` and `encoder_profiling/` code imports and depends on
`src/proteina/` (it is not separable from it), so it is also a derivative work
and inherits the same non-commercial limitation.

**Therefore the entire project may be used for non-commercial research or
evaluation purposes only.** The top-level `LICENSE` is the NVIDIA License.

The `src/tabasco/` fork remains independently available under MIT; the MIT
copyright notice is retained in `src/tabasco/LICENSE`.

## Attribution

- NVIDIA Proteina — https://research.nvidia.com/labs/genair/proteina/ —
  see `src/proteina/LICENSE` for the full NVIDIA License text and the original
  per-file copyright headers (retained unmodified).
- Tabasco, by Carlos Vonessen — see `src/tabasco/LICENSE` (MIT).
