# What is original work, and what is built on prior code

This submission combines original work by the author with two pre-existing
open-source codebases that were forked and extended. This document states
precisely which parts are which, so that the original contribution can be
assessed without reverse-engineering it.

The two forks are vendored in-place under `src/` (their full source is
included directly in this zip, frozen at the commits below — there are no
live git submodules to fetch).

## Entirely the author's own work

These top-level directories were written from scratch for this project and do
not derive from either upstream codebase:

- `evaluation/`       — all generation, representation, alignment, and variance
                        metrics + the sweep/plotting harness behind the report
                        tables and figures (FPSD, ssJSD-2D, designability,
                        representation probes, CKNNA, etc.).
- `encoder_profiling/`— the encoder characterisation framework and findings
                        (CheMeleon, MACE, GearNet, ESM2, MPNN).
- `tests/`            — the test suite for both models' REPA paths.

## `src/proteina/` — fork of NVIDIA Proteina

- Upstream:   NVIDIA Proteina (https://research.nvidia.com/labs/genair/proteina/)
- Fork point: `origin/main` (the unmodified NVIDIA baseline, included as a branch)
- This zip:   our `repa` branch @ `7dde00558c2a58d50290b4854271152b4d74c7fa`
- License:    NVIDIA License — non-commercial, research/evaluation use only
              (see `src/proteina/LICENSE` and the top-level `NOTICE.md`).

The author's contribution on top of the NVIDIA baseline is **343 files,
~14,800 inserted lines**. The complete line-level diff against the NVIDIA
baseline is provided at:

- `CONTRIBUTIONS/proteina_repa.patch`       (full diff)
- `CONTRIBUTIONS/proteina_repa.diffstat.txt` (per-file summary)

The core of the contribution (all newly authored):

- `proteinfoundation/repa/`                 — the REPA package:
    - `repa_loss.py`, `proteina_repa.py`    — REPA alignment loss + projector
    - `gearnet_encoder.py`, `esm_encoder.py`,
      `mpnn_encoder.py`                      — target-encoder wrappers
    - `protein_transformer_repa.py`         — REPA-instrumented backbone
    - `pyg_compat.py`                        — PyG compatibility shims
- `proteinfoundation/train_repa.py`         — REPA training entrypoint
- `proteinfoundation/callbacks/generation_metrics.py`,
  `proteinfoundation/datasets/lmdb_dataset.py`,
  `proteinfoundation/utils/length_bucket_sampler.py`,
  `proteinfoundation/metrics/tm_score.py`   — supporting infrastructure
- `configs/experiment_config/training/...`  — the REPA training sweep configs

Modified NVIDIA files (REPA hooks, LMDB data path, metrics extensions) are
listed in the diffstat.

## `src/tabasco/` — fork of Tabasco

- Upstream:   Tabasco, by Carlos Vonessen
- Fork point: `097eaae106e90a88294a93d42a3f91f1798f383f` (last upstream commit)
- This zip:   `main` @ `cfb5189e2e4d3a5103df830592e636e3edf368dc`
- License:    MIT (see `src/tabasco/LICENSE`).

The author's contribution on top of the Tabasco baseline is **48 files,
~2,000 inserted lines**. Full diff:

- `CONTRIBUTIONS/tabasco_repa.patch`
- `CONTRIBUTIONS/tabasco_repa.diffstat.txt`

The core of the contribution:

- `src/tabasco/models/components/encoders.py` — ChemPropEncoder (CheMeleon) and
                                                 MACEEncoder REPA target encoders
- `src/tabasco/models/components/losses.py`   — REPALoss for the molecular model
- `src/tabasco/models/flow_model.py`,
  `src/tabasco/models/components/transformer_module.py`
                                              — REPA hidden-state hooks
- `src/tabasco/data/components/lmdb_unconditional.py`,
  `src/tabasco/data/lmdb_datamodule.py`       — SMILES-threaded data pipeline
- `configs/experiment/{qm9,geom}/`            — REPA experiment configs

## Anonymisation note

This zip has been scrubbed of author-identifying information (username, paths,
project/account names) for anonymous marking. The code and results are
otherwise unmodified.
